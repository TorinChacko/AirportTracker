#ifndef GEO_H_
#define GEO_H_

struct GeoLocation {
    double latitude;
    double longitude;
};

#endif // GEO_H_
